package com.green.todo.common.model;


public class GlobalConst {
    public static final int countOfCalendar = 3;
}
